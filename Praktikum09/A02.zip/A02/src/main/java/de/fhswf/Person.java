package de.fhswf;

public abstract class Person {

	public String Vorname;
	public String Nachname;
	public String Plz;
	public String Ort;
	public String Strasse;

}