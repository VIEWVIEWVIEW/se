package de.fhswf;

public class Angestellter extends Person {
	public long Eintrittsdatum;
}