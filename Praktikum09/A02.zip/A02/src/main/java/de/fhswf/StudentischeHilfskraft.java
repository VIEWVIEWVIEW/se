package de.fhswf;

import java.math.BigInteger;

public class StudentischeHilfskraft extends Person {

	public String Matrikelnummer;
	public long BeginnArbeitsvertrag;
	public long EndeArbeitsvertrag;
	public static BigInteger Stundenlohn;

}